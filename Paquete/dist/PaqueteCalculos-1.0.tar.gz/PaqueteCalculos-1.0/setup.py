from setuptools import setup

setup(

    name="PaqueteCalculos",
    version="1.0",
    description="Paquete de calculos",
    author="Vladimir",
    author_email="vladimir@gmail.com",
    url="www.vladimirweb.com",
    packages=["calculos", "calculos.basicos"] #primero especifico la carpeta, luego la ruta al .py


)