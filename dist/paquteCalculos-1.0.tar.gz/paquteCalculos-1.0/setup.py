from setuptools import setup, version

setup(

    name="paquteCalculos",
    version="1.0",
    description="Paquete de redondeo y potencia",
    author="Vladimir",
    author_email="vladimirgutierrez4063@gmail.com",
    url="www.vladimirweb.com",
    packages=["calculos", "calculos.redondeoYpotencia"] #primero especifico la carpeta, luego la ruta al .py

)